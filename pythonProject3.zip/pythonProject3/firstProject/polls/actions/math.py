def add(a,b):
    return a + b


def sub(a,b):
    return a - b

def mul(a,b):
    return a * b

def truediv(a,b):
    if b==0:
        return 'йогурт'
    return a / b