from django.contrib.admin import action
from django.http import  HttpResponse, HttpRequest

def index(request: HttpRequest):
    from .actions import math
    a = int(request.GET.get('a'))
    b = int(request.GET.get('b'))
    c = request.GET.get('choice', '+')

    if c == '+':
        return HttpResponse(math.add(a,b))

    elif c == '-':
        return HttpResponse(math.sub(a,b))

    elif c == '*':
        return HttpResponse(math.mul(a,b))

    elif c == '/':
        return HttpResponse(math.truediv(a,b))

    else:
        return HttpResponse('ты дурак!')

def products(request: HttpRequest):
    print(request.path_info)
    products = [f'p{i}' for i in range(10)]
    return HttpResponse(products)

def fio(request):
    return HttpResponse('Чупин Степан Сергеевич')