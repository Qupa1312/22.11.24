from django.contrib import admin
from django.urls import path, re_path

from polls import views

app_name = 'polls'

urlpatterns = [
    re_path('add/', views.index, name='add'),
    re_path(r'^products/\d+/', views.products, name='products'),
    re_path('fio/', views.fio, name='fio')
]